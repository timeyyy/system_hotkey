Easily register and unregister system wide/global hotkeys for python 3 on either windows or linux
