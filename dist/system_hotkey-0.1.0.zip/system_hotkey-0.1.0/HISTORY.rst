Original Release
================

To be done
----------

Mac support

eta > 6 months
